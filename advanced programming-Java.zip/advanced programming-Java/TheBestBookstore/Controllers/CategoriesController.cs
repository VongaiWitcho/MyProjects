﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using TheBestBookstore.Data;
using TheBestBookstore.Models;
using System.Linq;

namespace TheBestBookstore.Controllers
{
    public class CategoriesController : Controller
    {
        private ApplicationDbContext db;

        public CategoriesController(ApplicationDbContext db)
        {
            this.db = db;
        }

        [HttpGet]
        public IActionResult Index()
        {
            List<Category> categories = db.Categories.ToList();
            return View(categories);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Category category)
        {
            // Check if category name already exists
            if (db.Categories.Any(c => c.Name == category.Name))
            {
                ModelState.AddModelError("Name", "This category already exists.");
                return View(category);
            }

            // Saving the category in db
            db.Categories.Add(category);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            var category = db.Categories.Find(id);

            if (category == null)
            {
                return NotFound();
            }

            return View(category);
        }

        [HttpPost]
        public IActionResult Edit(int id, Category category)
        {
            if (id != category.Id)
            {
                return BadRequest();
            }

            var existingCategory = db.Categories.Find(id);
            if (existingCategory == null)
            {
                return NotFound();
            }

            // Check if another category with the same name already exists
            if (db.Categories.Any(c => c.Name == category.Name && c.Id != id))
            {
                ModelState.AddModelError("Name", "This category name is already taken.");
                return View(category);
            }

            // Update the existing category with the new values
            existingCategory.Name = category.Name;
            existingCategory.Description = category.Description;
            db.SaveChanges();

            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            var category = db.Categories.Find(id);

            if (category == null)
            {
                return NotFound();
            }

            return View(category);
        }

        [HttpPost, ActionName("Delete")]
        public IActionResult DeleteConfirmed(int id)
        {
            var category = db.Categories.Find(id);

            if (category == null)
            {
                return NotFound();
            }

            db.Categories.Remove(category);
            db.SaveChanges();

            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult Details(int id)
        {
            var category = db.Categories.Find(id);

            if (category == null)
            {
                return NotFound();
            }

            return View(category);
        }
    }
}
