﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using TheBestBookstore.Data;
using TheBestBookstore.Models;
using System.Linq;

namespace TheBestBookstore.Controllers
{
    public class BooksController : Controller
    {
        private ApplicationDbContext db;

        public BooksController(ApplicationDbContext db)
        {
            this.db = db;
        }

        public IActionResult Index(string searchString, string searchBy)
        {
            var books = db.Books.Include(b => b.Category).AsQueryable();

            if (!string.IsNullOrEmpty(searchString))
            {
                switch (searchBy)
                {
                    case "Title":
                        books = books.Where(b => b.Title.Contains(searchString));
                        break;
                    case "Author":
                        books = books.Where(b => b.Author.Contains(searchString));
                        break;
                    case "Category":
                        books = books.Where(b => b.Category.Name.Contains(searchString));
                        break;
                    default:
                        break;
                }
            }

            return View(books.ToList());
        }

        [HttpGet]
        public IActionResult Create()
        {
            var cats = db.Categories.ToList();
            ViewBag.Categories = new SelectList(cats, "Id", "Name");
            return View();
        }

        [HttpPost]
        public IActionResult Create(Book book)
        {
            if (db.Books.Any(b => b.Title == book.Title))
            {
                ModelState.AddModelError("Title", "The title was inputted already.");
            }

            if (book.Pages <= 0)
            {
                ModelState.AddModelError("Pages", "The number of pages must be greater than 0.");
            }

            if (ModelState.IsValid)
            {
                db.Books.Add(book);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            var cats = db.Categories.ToList();
            ViewBag.Categories = new SelectList(cats, "Id", "Name");
            return View();
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            var book = db.Books.Include(b => b.Category).FirstOrDefault(b => b.Id == id);

            if (book == null)
            {
                return NotFound();
            }

            var categories = db.Categories.ToList();
            ViewBag.Categories = new SelectList(categories, "Id", "Name", book.CategoryId);

            return View(book);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, [Bind("Id,Title,Author,Published,Pages,CategoryId")] Book book)
        {
            if (id != book.Id)
            {
                return NotFound();
            }

            if (db.Books.Any(b => b.Title == book.Title && b.Id != id))
            {
                ModelState.AddModelError("Title", "The title was inputted already.");
            }

            if (book.Pages <= 0)
            {
                ModelState.AddModelError("Pages", "The number of pages must be greater than 0.");
            }

            if (ModelState.IsValid)
            {
                try
                {
                    db.Update(book);
                    db.SaveChanges();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!BookExists(book.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }

            var cats = db.Categories.ToList();
            ViewBag.Categories = new SelectList(cats, "Id", "Name");

            return View(book);
        }

        private bool BookExists(int id)
        {
            return db.Books.Any(e => e.Id == id);
        }

        [HttpGet]
        public IActionResult Delete(int id)
        {
            var book = db.Books.Find(id);
            if (book == null)
            {
                return NotFound();
            }
            return View(book);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            var book = db.Books.Find(id);
            if (book != null)
            {
                db.Books.Remove(book);
                db.SaveChanges();
            }
            return RedirectToAction(nameof(Index));
        }

        [HttpGet]
        public IActionResult Details(int id)
        {
            var book = db.Books.Include(b => b.Category).FirstOrDefault(b => b.Id == id);
            if (book == null)
            {
                return NotFound();
            }
            return View(book);
        }
    }
}
